import os, bcrypt, json
from pathlib import Path
import google.generativeai as genal
class API_Database():
    def __init__(self):
        os.chdir(Path(__file__).parent)
        
        genal.configure(api_key='AIzaSyBVmQQdFJYss-Hqu2gb4-dzV3nckQSug5o')
        self.model = genal.GenerativeModel('gemini-1.5-flash')
        
    def get_text_ai(self, text):
        response = self.model.generate_content(f"{text}")
        return response.text

    # def username_exists(self, username):
    #     user = self.load_account()
    #     if user:
    #         return username in self.load_account()
    #     return False
        
    # def load_account(self):
    #     if not os.path.exists(self.path_file) or not os.path.getsize(self.path_file):
    #         with open(self.path_file, "w") as file:
    #             file.write("")
    #         return
    #     with open(self.path_file, "r") as file:
    #         user = {}
    #         for line in file:
    #             if ":" in line:
    #                 username,password = line.strip().split(":", 1)
    #                 user[username] = password
    #     return user
    
    # def save_account(self, username, password):
    #     if not self.username_exists(username):
    #         pw_hash = self.hash_password(password)
    #         with open(self.path_file, "a+") as file:
    #             file.write(f"{username}:{pw_hash.decode('utf-8')}\n")
                
class AccountItem:
    def __init__(self, id, username, password, image=None):
        self.id = id
        self.username = username
        self.password = password
        self.image = image
        
class DatabaseAccount():
    def __init__(self):
        self.file_path = Path(__file__).parent.parent / "Resource" / "database.json"
        self.account_data = list()
        
        while True:
            try:
                self.account_data = self.load_json()
                break
            except:
                self.save_json(self.account_data)
    
    def load_json(self):
        with open(self.file_path, "r") as file:
            return json.load(file)

    def save_json(self, data):
        with open(self.file_path, "w") as file:
            json.dump(data, file, indent=4)
    
    def get_data(self, username) -> AccountItem:
        for account in self.account_data:
            if account.get("username") == username:
                return account
        return None
    
    def add_account(self, username, password, image=None):
        self.account_data.append(
            {
                "id": len(self.account_data)+1, 
                "username": username, 
                "password": self.hash_password(password).decode("utf-8"),
                "image": image
            }
        )
        self.save_json(self.account_data)

    def username_exists(self, username):
        return self.get_data(username)

    def hash_password(self, password):
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'),salt)

    def check_password(self, username, plain_password):
        return bcrypt.checkpw(plain_password.encode("utf-8"), self.get_data(username).get("password").encode("utf-8"))