# import os
# from pathlib import Path
# from PyQt6 import uic, QtCore, QtWidgets
# from PyQt6.QtWidgets import QMainWindow, QMessageBox

# class Search(QMainWindow):
#     def __init__(self, signal=None):
#         super().__init__()
#         os.chdir(Path(__file__).parent)
#         self.ui = uic.loadUi('../ui/Search.ui', self)
        
#         # Thiết lập để lấy lại vị trí cũ và signal
#         self.old_pos = None
#         self.signal = signal
        
#         # Thiết lập xóa bỏ các nút tắt, thu nhỏ, phóng to
#         self.setWindowFlag(QtCore.Qt.WindowType.FramelessWindowHint)
#         self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
        
#         # Tìm các widget theo tên trong file .ui
#         self.search_input = self.findChild(QtWidgets.QLineEdit, "lineEdit")  # Ô nhập
#         self.result_list = self.findChild(QtWidgets.QListWidget, "listWidget")  # Danh sách kết quả

#         self.result_list.hide()  # Ban đầu ẩn danh sách
        
#         # Danh sách sản phẩm có sẵn
#         self.products = [
#             "Yellowstone National Park (USA)", "Moraine Lake (Canada)", "Wadi Rum (Jordan)", "Jotunheimen (Norway)"
#             "White Beach (Boracay, Philippines)", "Maya Bay (Thailand)", "Nusa Dua Beach (Bali, Indonesia)","Navagio Beach (Greece)"
#             "Glacier Bay National Park, USA", "Grand Canyon, Arizona, USA", "Dalmatian Coast, Croatia", "Ha Long Bay, Vietnam"
#             "Mount Fuji (Japan)", "Himalayas (Nepal)", "Alps (France, Switzerland, Italy)", "Mount Everest (Nepal)"
#         ]

#         # Sự kiện khi nhập thay đổi
#         self.search_input.textChanged.connect(self.search_product)
        
#         # Kết nối sự kiện click vào QListWidget
#         self.setup_list_widget_events()

#     def setup_list_widget_events(self):
#         """Kết nối sự kiện click của QListWidget"""
#         self.result_list.itemClicked.connect(self.open_product_detail)

#     def search_product(self):
#         """Lọc danh sách sản phẩm theo từ khóa nhập vào và hiển thị ngay lập tức"""
#         keyword = self.search_input.text().strip().lower()
#         self.result_list.clear()  # Xóa kết quả cũ

#         if keyword:  # Nếu có từ khóa
#             filtered_products = [p for p in self.products if keyword in p.lower()]
#             if filtered_products:
#                 self.result_list.addItems(filtered_products)  # Hiển thị kết quả lọc
#                 self.result_list.show()  # Hiện danh sách ngay khi có kết quả
#             else:
#                 self.result_list.hide()  # Ẩn nếu không có kết quả phù hợp
#         else:
#             self.result_list.hide()  # Ẩn khi không có dữ liệu
    
#     def open_product_detail(self, item):
#         """Mở giao diện chi tiết dựa vào sản phẩm được chọn"""
#         product_name = item.text().lower()

#         if "Yellowstone National Park (USA)" in product_name:
#             self.yellowstoneNationalPark_show()
#         elif "Moraine Lake (Canada)" in product_name:
#             self.moraineLake_show()
#         elif "Wadi Rum (Jordan)" in product_name:
#             self.wadiRum_show()
#         else:
#             self.mayaBay_show()
    
#     def main_interface_show(self):
#         self.close()
#         if self.signal:
#             self.signal.main_interface.emit(self.pos())
#     def yellowstoneNationalPark_show(self):
#         self.close()
#         self.signal.yellowstoneNationalPark.emit(self.pos())
#     def moraineLake_show(self):
#         self.close()
#         self.signal.moraineLake.emit(self.pos())
#     def wadiRum_show(self):
#         self.close()
#         self.signal.wadiRum.emit(self.pos())
#     def jotunheimen_show(self):
#         self.close()
#         self.signal.jotunheimen.emit(self.pos())
#     def whiteBeach_show(self):
#         self.close()
#         self.signal.whiteBeach.emit(self.pos())
#     def mayaBay_show(self):
#         self.close()
#         self.signal.mayaBay.emit(self.pos())
#     def navagioBeach_show(self):
#         self.close()
#         self.signal.navagioBeach.emit(self.pos())
#     def nusaDua_show(self):
#         self.close()
#         self.signal.nusaDua.emit(self.pos())
#     def glacierBay_show(self):
#         self.close()
#         self.signal.glacierBay.emit(self.pos())
#     def grandCanyon_show(self):
#         self.close()
#         self.signal.grandCanyon.emit(self.pos())
#     def dalmatianCoast_show(self):
#         self.close()
#         self.signal.dalmatianCoast.emit(self.pos())
#     def haLongBay_show(self):
#         self.close()
#         self.signal.haLongBay.emit(self.pos())
#     def mountFuji_show(self):
#         self.close()
#         self.signal.mountFuji.emit(self.pos())
#     def himalaya_show(self):
#         self.close()
#         self.signal.himalaya.emit(self.pos())
#     def alps_show(self):
#         self.close()
#         self.signal.alps.emit(self.pos())
#     def everest_show(self):
#         self.close()
#         self.signal.everest.emit(self.pos())
#     def search_open(self):
#         self.show()

#     # <-- Nâng cao cho chương trình -->
#     # Giúp chương trình có thể di chuyển và lấy được vị trí cũ

#     def mousePressEvent(self, event):
#         if event.button() == QtCore.Qt.MouseButton.LeftButton:
#             self.old_pos = event.globalPosition().toPoint()
    
#     def mouseMoveEvent(self, event):
#         if self.old_pos is not None:
#             delta = event.globalPosition().toPoint() - self.old_pos
#             self.move(self.pos() + delta)
#             self.old_pos = event.globalPosition().toPoint()
            
#     def mouseReleaseEvent(self, event):
#         if event.button() == QtCore.Qt.MouseButton.LeftButton:
#             self.old_pos = None
    
#     def keyPressEvent(self, event):
#         if event.key() == QtCore.Qt.Key.Key_Escape:
#             self.close_application()
    
#     def close_application(self):
#         reply = QMessageBox.question(
#             self, 'Exit', 'Are you sure you want to exit?', 
#             QMessageBox.StandardButton.Yes | 
#             QMessageBox.StandardButton.No, QMessageBox.StandardButton.No
#         )
#         if reply == QMessageBox.StandardButton.Yes:
#             self.close()
                    
# # if __name__ == "__main__":
# #     from PyQt6.QtWidgets import QApplication
# #     import sys
# #     app = QApplication(sys.argv)
# #     window = Search()
# #     window.show()
# #     app.exec()
    