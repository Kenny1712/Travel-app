import sys
import json
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel,
    QScrollArea, QMainWindow, QFrame
)
from PyQt6.QtCore import Qt


FAVORITE_FILE = "favorites.json"

class FavoriteWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)
        self.load_favorites()

    def load_favorites(self):
        self.layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        # Clear cũ
        for i in reversed(range(self.layout.count())):
            widget = self.layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        try:
            with open(FAVORITE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            data = []

        for place in data:
            label = QLabel(place)
            label.setFrameStyle(QFrame.Shape.Box | QFrame.Shadow.Raised)
            self.layout.addWidget(label)

    def add_favorite(self, place_name):
        # Lưu JSON
        try:
            with open(FAVORITE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            data = []

        if place_name not in data:
            data.append(place_name)
            with open(FAVORITE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)

        # Update giao diện
        self.load_favorites()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Favorite Places")

        # Scroll Area cho Favorites
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)

        self.favorite_widget = FavoriteWidget()
        self.scroll.setWidget(self.favorite_widget)

        # Nút Add test
        self.add_button = QPushButton("Add to Favorite: Paris")
        self.add_button.clicked.connect(lambda: self.favorite_widget.add_favorite("Paris"))

        self.add_button2 = QPushButton("Add to Favorite: Tokyo")
        self.add_button2.clicked.connect(lambda: self.favorite_widget.add_favorite("Tokyo"))

        container = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(self.add_button)
        layout.addWidget(self.add_button2)
        layout.addWidget(self.scroll)
        container.setLayout(layout)

        self.setCentralWidget(container)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.resize(400, 400)
    window.show()
    sys.exit(app.exec())
