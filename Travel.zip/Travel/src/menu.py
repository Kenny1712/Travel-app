import os
from pathlib import Path
from PyQt6 import uic, QtCore
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QListWidget

class Menu (QMainWindow):
    def __init__(self, signal=None):
        super().__init__()
        os.chdir(Path(__file__).parent)
        self.ui = uic.loadUi('../ui/Menu.ui', self)
        
        # Thiết lập để lấy lại vị trí cũ và sinal
        self.old_pos = None
        self.signal = signal
        
        # Thiết lập xóa bỏ các nút tắt, thu nhỏ, phóng to
        self.setWindowFlag(QtCore.Qt.WindowType.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
        
        self.ui.listWidget.hide()
        
        self.products = [
            "Yellowstone National Park (USA)", "Moraine Lake (Canada)", "Wadi Rum (Jordan)", "Jotunheimen (Norway)"
            "White Beach (Boracay, Philippines)", "Maya Bay (Thailand)", "Nusa Dua Beach (Bali, Indonesia)","Navagio Beach (Greece)"
            "Glacier Bay National Park, USA", "Grand Canyon, Arizona, USA", "Dalmatian Coast, Croatia", "Ha Long Bay, Vietnam"
            "Mount Fuji (Japan)", "Himalayas (Nepal)", "Alps (France, Switzerland, Italy)", "Mount Everest (Nepal)"
        ]
        
        self.ui.lineEdit.textChanged.connect(self.search_product)
        # self.setup_list_widget_events()
        
        self.ui.pushButton.clicked.connect(self.main_interface_show)
        self.ui.pushButton_7.clicked.connect(self.welcome2_show)
        # self.ui.pushButton_2.clicked.connect(self.search_show)
    
        self.setup_list_widget_events()
    
    def setup_list_widget_events(self):
        """Kết nối sự kiện click của QListWidget"""
        self.listWidget.itemClicked.connect(self.open_product_detail)
    
    def search_product(self):
        """Lọc danh sách sản phẩm theo từ khóa nhập vào và hiển thị ngay lập tức"""
        keyword = self.ui.lineEdit.text().strip().lower()
        self.ui.listWidget.clear()  # Xóa kết quả cũ

        if keyword:  # Nếu có từ khóa
            filtered_products = [p for p in self.products if keyword in p.lower()]
            if filtered_products:
                self.ui.listWidget.addItems(filtered_products)  # Hiển thị kết quả lọc
                self.ui.listWidget.show()  # Hiện danh sách ngay khi có kết quả
            else:
                self.ui.listWidget.hide()  # Ẩn nếu không có kết quả phù hợp
        else:
            self.ui.listWidget.hide()  # Ẩn khi không có dữ liệu
            
    def open_product_detail(self, item):
        """Mở giao diện chi tiết dựa vào sản phẩm được chọn"""
        product_name = item.text().lower()

        product_methods = {
            "yellowstone national park (usa)": self.yellowstoneNationalPark_show,
            "moraine lake (canada)": self.moraineLake_show,
            "wadi rum (jordan)": self.wadiRum_show,
            "jotunheimen (norway)":self.jotunheimen_show,  
            "white beach (boracay, philippines)": self.whiteBeach_show,  
            "maya bay (thailand)": self.mayaBay_show,  
            "nusa dua beach (bali, indonesia)": self.nusaDua_show,  
            "navagio beach (greece)": self.navagioBeach_show,  
            "glacier bay national park, usa": self.glacierBay_show,  
            "grand canyon, arizona, usa": self.grandCanyon_show,  
            "dalmatian coast, croatia": self.dalmatianCoast_show,  
            "ha long bay, vietnam": self.haLongBay_show,  
            "mount fuji (japan)": self.mountFuji_show,  
            "himalayas (nepal)": self.himalaya_show,  
            "alps (france, switzerland, italy)": self.alps_show,  
            "mount everest (nepal):": self.everest_show
        }
        
        product_methods.get(product_name)()
                    
    def welcome2_show(self):
        self.close()
        self.signal.main_interface.emit(self.pos())
    def menu_open(self):
        self.show()
        
    def main_interface_show(self):
        self.close()
        self.signal.main_interface.emit(self.pos())

    def yellowstoneNationalPark_show(self):
        self.close()
        self.signal.yellowstoneNationalPark.emit(self.pos())
        
    def moraineLake_show(self):
        self.close()
        self.signal.moraineLake.emit(self.pos())
        
    def wadiRum_show(self):
        self.close()
        self.signal.wadiRum.emit(self.pos())
        
    def jotunheimen_show(self):
        self.close()
        self.signal.jotunheimen.emit(self.pos())
        
    def whiteBeach_show(self):
        self.close()
        self.signal.whiteBeach.emit(self.pos())
        
    def mayaBay_show(self):
        self.close()
        self.signal.mayaBay.emit(self.pos())
        
    def navagioBeach_show(self):
        self.close()
        self.signal.navagioBeach.emit(self.pos())
        
    def nusaDua_show(self):
        self.close()
        self.signal.nusaDua.emit(self.pos())
        
    def glacierBay_show(self):
        self.close()
        self.signal.glacierBay.emit(self.pos())
        
    def grandCanyon_show(self):
        self.close()
        self.signal.grandCanyon.emit(self.pos())
        
    def dalmatianCoast_show(self):
        self.close()
        self.signal.dalmatianCoast.emit(self.pos())
        
    def haLongBay_show(self):
        self.close()
        self.signal.haLongBay.emit(self.pos())
        
    def mountFuji_show(self):
        self.close()
        self.signal.mountFuji.emit(self.pos())
        
    def himalaya_show(self):
        self.close()
        self.signal.himalaya.emit(self.pos())
        
    def alps_show(self):
        self.close()
        self.signal.alps.emit(self.pos())
        
    def everest_show(self):
        self.close()
        self.signal.everest.emit(self.pos())
        
# <-- Nâng cao cho chương trình -->
# Giúp chương trình có thể di chuyển và lấy được vị trí cũ

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.old_pos = event.globalPosition().toPoint()
    
    def mouseMoveEvent(self, event):
        if self.old_pos is not None:
            delta = event.globalPosition().toPoint() - self.old_pos
            self.move(self.pos() + delta)
            self.old_pos = event.globalPosition().toPoint()
            
    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.old_pos = None
    
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key.Key_Escape:
            self.close_application()
    
    def close_application(self):
        reply = QMessageBox.question(
                    self, 'Exit', 'Are you sure you want to exit?', 
                    QMessageBox.StandardButton.Yes | 
                    QMessageBox.StandardButton.No, QMessageBox.StandardButton.No
                )
        if reply == QMessageBox.StandardButton.Yes:
            self.close()
                    
# if __name__ == "__main__":
#    from PyQt6.QtWidgets import QApplication
#    import sys
#    app = QApplication(sys.argv)
#    windows = Menu()
#    windows.show()
#    app.exec()
    