import os , re
from pathlib import Path
from PyQt6 import uic, QtCore, QtWidgets
from PyQt6.QtWidgets import QMainWindow, QMessageBox

class Sign_in(QMainWindow):
    def __init__(self, signal=None):
        super().__init__()
        os.chdir(Path(__file__).parent)
        self.ui = uic.loadUi('../ui/Sign_in.ui', self)
        
        self.old_pos = None
        self.signal = signal
        
        self.setWindowFlag(QtCore.Qt.WindowType.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)

        self.ui.pushButton.clicked.connect(self.signup_show)
        self.ui.pushButton_2.clicked.connect(self.welcome2_show)
        self.ui.pushButton_3.clicked.connect(self.check_login)
        self.ui.checkBox.stateChanged.connect(self.toggle_password_visibility)
        
    def toggle_password_visibility(self):
        """
        Hiện hoặc ẩn mật khẩu dựa trên trạng thái của checkbox.
        """
        if self.ui.checkBox.isChecked():
            self.ui.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.EchoMode.Normal)
        else:
            self.ui.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
    def signin_open(self, position):
        self.show()
        self.move(position)

    def signup_show(self):
        self.ui.lineEdit.clear()
        self.ui.lineEdit_2.clear()
        self.close()
        self.signal.signup.emit(self.pos())

    def welcome2_show(self):
        self.ui.lineEdit.clear()
        self.ui.lineEdit_2.clear()
        self.close()
        self.signal.welcome2.emit(self.pos())

    def main_interface_show(self):
        self.ui.lineEdit.clear()
        self.ui.lineEdit_2.clear()
        self.close()
        self.signal.main_interface.emit(self.pos())
        
    def is_valid_username(self, username):
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        return re.match(email_regex, username) is not None
    
    def is_valid_password(self, password):
        pass_regex = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
        return re.match(pass_regex, password) is not None
    
    def check_login(self):
        username = self.ui.lineEdit.text()
        password = self.ui.lineEdit_2.text()
        if not username or not password:
            return self.show_message_box("Error notification","Username and password can't be emty", QMessageBox.Icon.Warning)
        if not self.is_valid_username(username):
            return self.show_message_box("Error notification","Wrong username", QMessageBox.Icon.Warning)
        if not self.signal.api_account.username_exists(username):
            return self.show_message_box("Error notification","Invalid username", QMessageBox.Icon.Warning)
        if not self.is_valid_password(password):
            return self.show_message_box("Error notification","Wrong password", QMessageBox.Icon.Warning)
        if not self.signal.api_account.check_password(username, password):
            return self.show_message_box("Error notification","Invalid Password", QMessageBox.Icon.Warning)
        self.show_message_box("Notification","Account logged in successfully")
        self.main_interface_show()
# <-- Nâng cao cho chương trình -->
# Giúp chương trình có thể di chuyển và lấy được vị trí cũ

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.old_pos = event.globalPosition().toPoint()
    
    def mouseMoveEvent(self, event):
        if self.old_pos is not None:
            delta = event.globalPosition().toPoint() - self.old_pos
            self.move(self.pos() + delta)
            self.old_pos = event.globalPosition().toPoint()
            
    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.old_pos = None
    
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key.Key_Escape:
            self.close_application()
    
    def close_application(self):
        reply = QMessageBox.question(
                    self, 'Exit', 'Are you sure you want to exit?', 
                    QMessageBox.StandardButton.Yes | 
                    QMessageBox.StandardButton.No, QMessageBox.StandardButton.No
                )
        if reply == QMessageBox.StandardButton.Yes:
            self.close()
    
    def show_message_box(self, title="Message box", content="This is a message box", icon=QMessageBox.Icon.Information):
        msg = QMessageBox()
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.setWindowTitle(title)
        msg.setText(content)
        msg.setIcon(icon)
        msg.exec()
                        
#if __name__ == "__main__":
#    from PyQt6.QtWidgets import QApplication
#    import sys
#    app = QApplication(sys.argv)
#    windows = Sign_in()
#    windows.show()
#    app.exec()
    