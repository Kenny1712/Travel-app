import os
from pathlib import Path
from PyQt6 import uic, QtCore
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QLabel, QVBoxLayout

class main_AI(QMainWindow):
    def __init__(self, signal=None):
        super().__init__()
        os.chdir(Path(__file__).parent)
        self.ui = uic.loadUi('../ui/Main_ai.ui', self)
        
        self.old_pos = None
        self.signal = signal
        
        self.setWindowFlag(QtCore.Qt.WindowType.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
        
        self.scroll_layout = QVBoxLayout(self.ui.scrollAreaWidgetContents)
        self.scroll_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)
        
        self.ui.pushButton.clicked.connect(self.add_message_to_scroll_area)
        self.ui.pushButton_2.clicked.connect(self.main_interface_show)
    def ai_open(self):
        self.show()
    def main_interface_show(self):
        self.close()
        self.signal.main_interface.emit(self.pos())

    def add_message_to_scroll_area(self):
        message = self.ui.textEdit.toPlainText().strip()

        if message:
            message_label = QLabel(message, self)
            message_label.setStyleSheet("""
                padding: 5px;
                border-radius: 10px;
                border-bottom-right-radius: 2px;
                font-size: 14px;
                border: 1px solid lightgray;
                margin-left: 50px;
                color: rgb(255, 255, 255);
                background-color: rgb(255, 145, 77);
            """)
            message_label.setWordWrap(True)
            message_label.adjustSize()

            self.ui.scroll_layout.addWidget(message_label)
            self.ui.textEdit.clear()
            QtCore.QTimer.singleShot(100, lambda: self.reponse_ai(message))
            
    def reponse_ai(self, message):
        message = self.signal.api.get_text_ai(message)
        # message = self.AI.get_text_ai(message)
        message_label = QLabel(message, self)
        message_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignJustify)
        # message_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        message_label.setStyleSheet("""
            padding: 5px;
            border-radius: 10px;
            border-bottom-left-radius: 2px;
            font-size: 14px;
            border: 1px solid lightgray;
            margin-right: 50px;
        """)
        message_label.setWordWrap(True)
        message_label.adjustSize()

        self.scroll_layout.addWidget(message_label)          
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.old_pos = event.globalPosition().toPoint()
    
    def mouseMoveEvent(self, event):
        if self.old_pos is not None:
            delta = event.globalPosition().toPoint() - self.old_pos
            self.move(self.pos() + delta)
            self.old_pos = event.globalPosition().toPoint()
            
    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.old_pos = None
    
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key.Key_Escape:
            self.close_application()
    
    def close_application(self):
        reply = QMessageBox.question(
                    self, 'Exit', 'Are you sure you want to exit?', 
                    QMessageBox.StandardButton.Yes | 
                    QMessageBox.StandardButton.No, QMessageBox.StandardButton.No
                )
        if reply == QMessageBox.StandardButton.Yes:
            self.close()
            
# if __name__ == "__main__":
#     from PyQt6.QtWidgets import QApplication
#     import sys
#     app = QApplication(sys.argv)
#     windows = main_AI()
#     windows.show()
#     app.exec()